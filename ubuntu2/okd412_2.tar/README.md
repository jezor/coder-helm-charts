Poprawiony obraz
